import { Component, ViewChild, OnInit } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { PopupboxComponent } from '../popupbox/popupbox.component';
import { MysqldataService } from './Service/mysqldata.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { sample } from 'rxjs/operators';
import { DialogExampleComponent } from '../dialog-example/dialog-example.component';
import { FormControl } from '@angular/forms';
import  'rxjs/add/operator/map';
import { map } from 'rxjs/operators';


@Component({
  selector: 'app-mysql',
  templateUrl: './mysql.component.html',
  styleUrls: ['./mysql.component.css']
})

export class MysqlComponent implements OnInit {

  
  constructor(private http: HttpClient,public dialog:MatDialog){}

  
  // public TableHeader = [{ TableName: 'Employee Table' }];  
  // Displayedcolumn = ['Id', 'First Name', 'Gender', 'Qualification','Last Name','Salary','Practices'];

  employee : any;

  // loadData(){
  //   let headers = new HttpHeaders();
  // headers.append('Content-Type','application/json');
  //   this.http.get('http://localhost:8080/employee', {headers:headers}).subscribe(
  //     (response) =>{
  //       this.employee = response;
  //       console.log("Data :"+response);
  //       var sample=JSON.stringify(response);
  //       console.log(length);
  //     },
  //     (error)=> { console.log(error);}
  //   )

  // }

  tablename: any;
  // tables = new FormControl();
loadTable(){
  let headers = new HttpHeaders();
  headers.append('Content-Type','application/json');
  this.http.get('http://localhost:8080/tables', {headers:headers}).subscribe(
      (result) =>{
        this.tablename= result;
        console.log("Data:"+result);
        this.loadfiles();
      },
      (error)=> { console.log(error);}
    )
  }

  files: any[] | any;
  loadfiles(){
    let headers = new HttpHeaders();
  headers.append('Content-Type','application/json');
  this.http.get('http://localhost:8080/files', {headers:headers}).subscribe(
      (response) =>{
        this.files = response['files'];
       this.loadprocess();
      },
      (error)=> { console.log(error);}
    )
  }

  process: any[] | any;
  loadprocess(){
    let headers = new HttpHeaders();
  headers.append('Content-Type','application/json');
  this.http.get('http://localhost:8080/processname', {headers:headers}).subscribe(
      (response) =>{
        this.process = response['processes'];
        console.log("Data:"+this.process);
      },
      (error)=> { console.log(error);}
    )
  }

  // openDialog(){
  //   var length = this.employee.length;
  // this.dialog.open(DialogExampleComponent,{data:{length}});
  // }
  ngOnInit() {
    this.loadTable();
    
    // // url : "http://localhost:8080/employee";
    // this.http.post("http://localhost:8080/employee",{headers: headers}).subscribe((val)=>{
    //   console.log(val);
    // })
  }

}
//   datasource1:[];
//   displayedcolumn: string[] = ['Id', 'First_Name', 'Last_Name', 'Gender', 'Qualification', 'Salary','practices'];

//   constructor(private router: Router,private readonly mysqlservice:MysqlDataPreview){} 
//   dataSource: MatTableDataSource<employee>

//   applyFilter(filterValue: string) {
//     this.dataSource.filter = filterValue.trim().toLowerCase();
//   }

//   ngOnInit() {
//     this.mysqlservice.getAll({responseType:"json"}).subscribe(response=>{
//       this.datasource1 = response;
//       console.log(response);
//       var sample= JSON.stringify(response);
//       this.displayedcolumn =  ['Id', 'First_Name', 'Last_Name', 'Gender', 'Qualification', 'Salary','practices'];
//     });
//   }
// }
