export class Employee
{
    id: number;
    first_Name: string;
    gender:string;
    qualification:string;
    last_Name:string;
    salary:number;
    practices:string

 constructor(id,first_Name,gender,qualification,last_Name,salary,practices){
     this.id = id;
     this.first_Name = first_Name;
     this.gender= gender;
     this.qualification=qualification;
     this.last_Name=last_Name;
     this.salary= salary;
     this.practices=practices
 }

}