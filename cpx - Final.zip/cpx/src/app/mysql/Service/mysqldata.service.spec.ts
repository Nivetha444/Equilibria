import { TestBed } from '@angular/core/testing';

import { MysqldataService } from './mysqldata.service';

describe('MysqldataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MysqldataService = TestBed.get(MysqldataService);
    expect(service).toBeTruthy();
  });
});
