import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../Employee';

@Injectable({
  providedIn: 'root'
})
export class MysqldataService {

  // constructor(private http: HttpClient) { }

  // url : string = "http://localhost:8080/employee"
  
  // getemployee()
  // {
  //   return this.http.get<Employee[]>(this.url);
  // }
}
