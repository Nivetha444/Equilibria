import { Injectable } from '@angular/core';
import { HttpClient }   from '@angular/common/http';
import { Observable }   from 'rxjs';
// import { Elements } from '../accounts/accounts.model';


@Injectable()
  
export class AccountsService {

  // private serviceUrl = 'https://jsonplaceholder.typicode.com/users';

  // constructor(private http: HttpClient) { }
  // getUser(): Observable<Elements[]> {
  //   return this.http.get<Elements[]>(this.serviceUrl);
  // }
}
