import { Component, ViewChild } from '@angular/core';
import { PopupboxComponent } from '../popupbox/popupbox.component';
import { MatDialog } from '@angular/material';
import { SelectionModel, DataSource } from '@angular/cdk/collections';
import { MatTableDataSource, MatSort } from '@angular/material';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { AccountPreviewService } from './service/AccountPreview';
import { RevenuePreviewService } from './service/RevenuePreview';
import {  Router } from '@angular/router';

export interface PeriodicElement {
  Label: string;
  API_Name: string;
  Description: string;
  sync: string;
  Deployed: string;
}

export interface Elements {
  Accounts_weekly__c: string;
  Parent_Account_ID_18_Digit__c: string;
  PARENT_ACCOUNT_NAME__c: string;
  type: string;
  Code__c: number;
  Account_Owner_18_Digit_Id__c: number;
  Name: string;
  City__c: string;
  DUNS_NUMBER__c: null;
  District__c: string;
  ACCOUNT_SEGMENTATION_TYPE__c: string;
  ORACLE_PERSON_ID__c: number;
  Geo__c: string;
  INDUSTRY1__c: string;
  Account_Owner_Name__c: string;
  State__c: null;
  Country__c: string;
  Sub_District__c: string;
  Name__c: string;
  ACCOUNT_STANDING__c: string;
  CMT_NAME__c: string;
  SIC_DESC__c: null;
  Sic: number;
  VALIDATIONS__c: null;
  AccountNumber: number;
  AM_ROLE_TYPE__c: null;
  SUB_DISTRICT_CODE__c: string;
  Account_Record_Type__c: string;
  Id: null;
}

export interface Revenue {
  SFDC_Accounts__c: number;
  FY15__c: number;
  Revenue_Category_Code__c: string;
  FY16__c: number;
  FY18__c: number;
  FY19__c: number;
  FY20__c: number;
  FY17__c: number;
  Id: null;
  type: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { Label: 'Account', API_Name: 'Account Name_c', Description: 'Brief Description of Accounts', sync: '07/06/19', Deployed: 'Yes' },
  { Label: 'Revenue', API_Name: 'Revenue_c', Description: 'Brief Description of Revenue', sync: '07/06/19', Deployed: 'Yes' }
];


@Component({
  selector: 'app-salesforce',
  templateUrl: './salesforce.component.html',
  styleUrls: ['./salesforce.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class SalesforceComponent {

  panelOpenState = false;
  tableLabel;
  showRevenue = false;
  showAccount = false;

  constructor(private router: Router, public dialog: MatDialog, private readonly accountPreviewService: AccountPreviewService, private readonly revenuePreviewService: RevenuePreviewService) { }
  columnsToDisplay: string[] = ['select', 'Label', 'API_Name', 'Description', 'sync', 'Deployed'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);

  expandedElement: PeriodicElement | null;

  // for Accounts Tables
  datasources1 = [];
  displayedColumns: string[] = ['Name', 'Account_Owner_18_Digit_Id__c', 'Geo__c', 'CMT_NAME__c', 'Sub_District__c', 'Account_Owner_Name__c'];

  // for Revenue Table
  datasources2 = [];
  displayedColumns1: string[] = ['SFDC_Accounts__c', 'Revenue_Category_Code__c', 'FY15__c', 'FY16__c', 'FY17__c', 'FY18__c', 'FY19__c', 'FY20__c', 'type'];

  selection = new SelectionModel<PeriodicElement>(true, []);

  @ViewChild(MatSort) sort: MatSort;
  openDialog(): void {
    const dialogRef = this.dialog.open(PopupboxComponent, {
      width: '700px',
      height: '530px'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  navigateTo = (location) => {
    if (location) {
      this.router.navigate([location]);
  }
    return false;
  }
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: PeriodicElement): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.Label + 1}`;
  }

  onClick(element) {
    this.expandedElement = this.expandedElement === element ? null : element;
    this.tableLabel = element.Label;
  }

  calculateClassesAccount() {
    if (this.tableLabel == 'Account') {
      return 'block';
    } else {
      return 'none';
    }
  }

  calculateClassesRevenue() {
    if (this.tableLabel == 'Revenue') {
      return 'block';
    } else {
      return 'none';
    }
  }

  ngOnInit() {
    this.dataSource.sort = this.sort;
    this.accountPreviewService.getAll({})
      .subscribe(response => {
        this.datasources1 = response;
        this.displayedColumns = ['Name', 'Account_Owner_18_Digit_Id__c', 'Geo__c', 'CMT_NAME__c', 'Sub_District__c', 'Account_Owner_Name__c'];
      });

    this.revenuePreviewService.getAll({})
      .subscribe(response => {
        this.datasources2 = response;
        this.displayedColumns1 = ['SFDC_Accounts__c', 'Revenue_Category_Code__c', 'FY15__c', 'FY16__c', 'FY17__c', 'FY18__c', 'FY19__c', 'FY20__c', 'type'];
      });
  }

}
