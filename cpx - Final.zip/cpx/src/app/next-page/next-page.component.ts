import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatDialog } from '@angular/material';
import { DialogExampleComponent } from '../dialog-example/dialog-example.component';

@Component({
  selector: 'app-next-page',
  templateUrl: './next-page.component.html',
  styleUrls: ['./next-page.component.css']
})
export class NextPageComponent implements OnInit {

  constructor(private http: HttpClient,public dialog:MatDialog){}

  // employee: any;
  // loadData(){
  //   let headers = new HttpHeaders();
  // headers.append('Content-Type','application/json');
  //   this.http.get('http://localhost:8080/employee', {headers:headers}).subscribe(
  //     (response) =>{
  //       this.employee = response;
  //       console.log("Data :"+response);
  //       var sample=JSON.stringify(response);
  //     },
  //     (error)=> { console.log(error);}
  //   )

  // }

  // result: any;
  // data: string;
  // processingData(){
  //   let headers = new HttpHeaders();
  //   headers.append('Content-Type','application/json');
  //   this.http.post('http://localhost:8080/employee',this.result,{headers}).subscribe((response)=>{
  //     this.result= response;
  //     console.log(this.result.message);
  //    let vales = this.result.message;
  //    return vales;
  //   }
  //   )}

    output:string;
    result:string;
    postData(){
       this.http.post('http://localhost:8080/employee',{output:this.output}).toPromise().then((data:any)=>{
         console.log(data.message);
         this.result = data.message;
       })
    }

  // openDialog(){
  //   var vales = this.result.message;
  // this.dialog.open(DialogExampleComponent,{data:{vales}});
  // }

  ngOnInit() {
  }

}
